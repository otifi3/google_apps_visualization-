library(tidyverse)
library(ggplot2)
library(plyr)
library(plotly)
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("plyr")
install.packages("plotly")
install.packages("gridExtra")

  google_apps_data <- read.csv("E:\\google_apps_data.csv",stringsAsFactor = FALSE)
  reviews_data  <- read.csv("E:\\reviews_data.csv")
  names(google_apps_data)[9] <- "Content_Rating"
  names(google_apps_data)[11] <- "Last_Updated"
  names(google_apps_data)[12] <- "Current_Version"
  names(google_apps_data)[13] <- "Andriod_Version"
  names(google_apps_data)[9] <- "Content_Rating"
  names(google_apps_data)[11] <- "Last_Updated"
  names(google_apps_data)[12] <- "Current_Version"
  names(google_apps_data)[13] <- "Andriod_Version"
  google_apps_data <- subset(google_apps_data, select = -c(Size))
  google_apps_data <- subset(google_apps_data, select = -c(Genres))
  google_apps_data <- subset(google_apps_data, select = -c(Current_Version))
  google_apps_data <- google_apps_data %>% mutate(Installs = gsub(",", "", Installs))
  google_apps_data <- google_apps_data %>% mutate(Installs = gsub("\\+", "", Installs))
  google_apps_data <- google_apps_data %>% mutate(Price = gsub("\\$", "", Price))
  google_apps_data$Price <- as.numeric(google_apps_data$Price)
  google_apps_data$Installs <- as.integer(google_apps_data$Installs)
  google_apps_data <- google_apps_data %>% separate(Last_Updated, c("Days","months", "Years"), "-")
  google_apps_data <- subset(google_apps_data, select = -c(Days))
  reviews_data <- reviews_data[!(is.na(reviews_data$Sentiment_Polarity)),]
  reviews_data <- subset(reviews_data, select = -c(Translated_Review))
  google_apps_data$months <- match(google_apps_data$months, month.abb)
  count(google_apps_data, "months")
  google_apps_data<-google_apps_data[!(google_apps_data$Category == 1.9),]
  
  df2 <- subset(google_apps_data, select = c("Category","Rating"))
  df2<- df2[!(is.na(df2$Rating)),]
  df3 <- aggregate(Rating ~ Category, df2, mean)
  for(i in 1:nrow(google_apps_data))
  {
    for(j in 1:nrow(df3))
    {
      print("hi")
      if(is.na(google_apps_data[i,3]) & (google_apps_data[i,2] == df3[j,1]))
      {
        print(paste("google",google_apps_data[i,3]))
        google_apps_data[i,3] <- df3[j,2] 
        print(paste("google",google_apps_data[i,3]))
      }
      
    }
  }
  reviews_data$Negative <- ifelse(reviews_data$Sentiment == "Negative", 1, 0)
  reviews_data$Neutral  <- ifelse(reviews_data$Sentiment == "Neutral", 1, 0)
  reviews_data$Positive <- ifelse(reviews_data$Sentiment == "Positive", 1, 0)
  positive_reviews <- subset(reviews_data, select = c(App,Sentiment_Polarity, Sentiment_Subjectivity, Positive))
  positive_reviews <- ddply(positive_reviews, .(App), summarize, Positive = sum(Positive), Sentiment_Polarity = mean(Sentiment_Polarity),Sentiment_Subjectivity = mean(Sentiment_Subjectivity) )
  Negative_reviews <- subset(reviews_data, select = c(App, Sentiment_Polarity, Sentiment_Subjectivity, Negative))
  Neutral_reviews <- subset(reviews_data, select = c(App, Sentiment_Polarity, Sentiment_Subjectivity, Neutral))
  Neutral_reviews <- ddply(Neutral_reviews, .(App), summarize, Neutral = sum(Neutral), Sentiment_Polarity = mean(Sentiment_Polarity),Sentiment_Subjectivity = mean(Sentiment_Subjectivity) )
  Negative_reviews <- ddply(Negative_reviews, .(App), summarize, negative = sum(Negative), Sentiment_Polarity = mean(Sentiment_Polarity),Sentiment_Subjectivity = mean(Sentiment_Subjectivity) )
  ggplot(google_apps_data)+
    geom_bar(aes(x = as.factor(months),fill = Type), position = position_stack(reverse = TRUE))+
    theme(legend.position = "right")+
    theme_linedraw()+
    labs(title = "Type App Added Over The Month",
         x = "Months",
         y = "Count")